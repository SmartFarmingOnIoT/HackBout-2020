TEAM: RuntimeTerrorOnIoT
Team Number : 38

The above two folders consist the necessary codes for runninf the IoT project.

In order to make out project more efficient, reliable and consumer friendly, we have taken the approach of a Master_Slave system, wherein the Micro Controllers bearing the sensors, which are present at a Particular Node/ Area in the fiels can communicate with the main master through Serial Communication.

The initial concept was to use LORA and incorporate a wireless system, but, given the time constraints, we were unable to demonstrate the same. The same will be taken and worked on in the future. More updates shall be posted here soon with regard to the same. 

Using the Master-Slave Approach, we can minimalize the number of devices that need to be connected to the internet, increasing the overall efficiency in places where the internet connectivity isn't that great.

The custom built website was tailored specifically for the same, thus maximising the performance and user friendliness.

Multiple tasks can be done directly from the website without having to interact with the device, thus making ti a fully Smart Farming. Intuitive Graphs, Manual Override Controls, Weather Forecast and Future Weather prediction are a few things necessary to be implemented in this project. 

The custom built website was tailored specifically for the same, thus maximising the performance and user friendliness.
More can be understood by visiting the website: https://smartfarmingoniot.github.io/runtimeTerrorOnIoT/index.html
